# This script will be executed in late_start service mode
# More info in the main Magisk thread
echo always_on > /sys/devices/platform/13040000.mali/power_policy
stop logd
stop thermald
echo 3 > /proc/cpufreq/cpufreq_power_mode
echo 1 > /proc/cpufreq/cpufreq_imax_enable
echo 0 > /proc/cpufreq/cpufreq_imax_thermal_protect

setprop init.svc.thermal 0
setprop  init.svc.vendor.thermal-hal-2-0.mtk 1100
setprop  init.svc.thermal_manager 1
setprop init.svc_debug_pid.thermal 0
setprop init.svc_debug_pid.thermal-hal-2-0.mtk 0
setprop init.svc_debug_pid.thermal_manager 1

echo 30 > /dev/stune/background/schedtune.boost

echo 30 > /dev/stune/foreground/schedtune.boost


echo 30 > /dev/stune/rt/schedtune.boost


sleep 20
echo 1 > /proc/cpufreq/cpufreq_cci_mode
chmod 0444 /proc/cpufreq/cpufreq_cci_mode