# Respective credits to @KennyTekkz and @r6gayming

function run() {

while [[ -z $(resetprop sys.boot_completed) ]]; do sleep 5; done

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Starting Configuration.'"

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Modifying Zram Parameters...

─────█─▄▀█──█▀▄─█─────
────▐▌──────────▐▌────
────█▌▀▄──▄▄──▄▀▐█────
───▐██──▀▀──▀▀──██▌───
──▄████▄──▐▌──▄████▄──
░░░A N N I H I L A T I O N░░░
██████████████████████'"

swapoff /dev/block/zram0
echo "1" > /sys/block/zram0/reset
echo "4096000000" >/sys/block/zram0/disksize
echo "zstd" > /sys/block/zram0/comp_algorithm
mkswap /dev/block/zram0
swapon /dev/block/zram0

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Fixing Kernel Panic Parameters....

─────█─▄▀█──█▀▄─█─────
────▐▌──────────▐▌────
────█▌▀▄──▄▄──▄▀▐█────
───▐██──▀▀──▀▀──██▌───
──▄████▄──▐▌──▄████▄──
░░░A N N I H I L A T I O N░░░
██████████████████████'"

echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Adding Touch Response Improvements...

─────█─▄▀█──█▀▄─█─────
────▐▌──────────▐▌────
────█▌▀▄──▄▄──▄▀▐█────
───▐██──▀▀──▀▀──██▌───
──▄████▄──▐▌──▄████▄──
░░░A N N I H I L A T I O N░░░
██████████████████████'"

echo "0 0 0 0" > /proc/sys/kernel/printk 
echo "off" > /proc/sys/kernel/printk_devkmsg
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "N" > /sys/module/printk/parameters/cpu
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/pid
echo "N" > /sys/module/printk/parameters/time
echo "0" > /sys/kernel/printk_mode/printk_mode

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Implementing CPU and GPU parameters for stable Performance...'

█▓▒▓█▀██▀█▄░░▄█▀██▀█▓▒▓█
█▓▒░▀▄▄▄▄▄█░░█▄▄▄▄▄▀░▒▓█
█▓▓▒░░░░░▒▓░░▓▒░░░░░▒▓▓█'"

echo "0" > /proc/sys/kernel/nmi_watchdog
echo "0" > /proc/sys/kernel/compat-log
echo "Y" > /sys/module/bluetooth/parameters/disable_ertm
echo "Y" > /sys/module/bluetooth/parameters/disable_esco
echo "0" > /sys/module/dwc3/parameters/ep_addr_rxdbg_mask
echo "0" > /sys/module/dwc3/parameters/ep_addr_txdbg_mask
echo "0" > /sys/module/dwc3_msm/parameters/disable_host_mode
echo "0" > /sys/module/hid_apple/parameters/fnmode
echo "0" > /sys/module/hid/parameters/ignore_special_drivers
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_3button
echo "N" > /sys/module/hid_magicmouse/parameters/emulate_scroll_wheel
echo "0" > /sys/module/hid_magicmouse/parameters/scroll_speed
echo "Y" > /sys/module/mdss_fb/parameters/backlight_dimmer
echo "Y" > /sys/module/workqueue/parameters/power_efficient
echo "N" > /sys/module/sync/parameters/fsync_enabled
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/debug/parameters/enable_event_log
echo "0" > /sys/module/glink/parameters/debug_mask
echo "N" > /sys/module/ip6_tunnel/parameters/log_ecn_error
echo "0" > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
echo "0" > /sys/module/msm_show_resume_irq/parameters/debug_mask
echo "0" > /sys/module/msm_smd_pkt/parameters/debug_mask
echo "N" > /sys/module/sit/parameters/log_ecn_error
echo "0" > /sys/module/smp2p/parameters/debug_mask
echo "0" > /sys/module/usb_bam/parameters/enable_event_log
echo "Y" > /sys/module/printk/parameters/console_suspend
echo "N" > /sys/module/printk/parameters/cpu
echo "Y" > /sys/module/printk/parameters/ignore_loglevel
echo "N" > /sys/module/printk/parameters/pid
echo "N" > /sys/module/printk/parameters/time
echo "0" > /sys/module/service_locator/parameters/enable
echo "1" > /sys/module/subsystem_restart/parameters/disable_restart_work

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Running Dex2oat compilations...
─────█─▄▀█──█▀▄─█─────
────▐▌──────────▐▌────
────█▌▀▄──▄▄──▄▀▐█────
───▐██──▀▀──▀▀──██▌───
──▄████▄──▐▌──▄████▄──
░░░A N N I H I L A T I O N░░░
██████████████████████'"

find /sys/ -name debug_mask -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/ -name debug_level -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/ -name edac_mc_log_ce -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/ -name edac_mc_log_ue -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/ -name enable_event_log -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/ -name log_ecn_error -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/ -name snapshot_crashdumper -exec sh -c 'echo "0" > "$1"' _ {} \;
find /sys/kernel/debug/kgsl/kgsl-3d0/ -name '*log*' -exec sh -c 'echo "0" > "$1"' _ {} \;

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Disabling sched boosts and logs...
─▄───▄▄▄▄▄▄▄───▄─
▀▀▄▄█████████▄▄▀▀
───██─▀███▀─██───
──▄▀████▀████▀▄──
▀█───██▀█▀██───█▀
░A N N I H I L A T I O N░
██████████████████'"
for sched in /sys/kernel/debug/sched_features/*; do
  echo "NO_GENTLE_FAIR_SLEEPERS" > "$sched"
  echo "NO_HRTICK" > "$sched"
  echo "NO_DOUBLE_TICK" > "$sched"
  echo "NO_RT_RUNTIME_SHARE" > "$sched"
  echo "NEXT_BUDDY" > "$sched"
  echo "NO_TTWU_QUEUE" > "$sched"
  echo "UTIL_EST" > "$sched"
  echo "ARCH_CAPACITY" > "$sched"
  echo "ARCH_POWER" > "$sched"
  echo "ENERGY_AWARE" > "$sched"
done
echo "0" > /proc/sys/kernel/sched_tunable_scaling

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Performing TCP congestion algorithm for stable network and ping...
─▄───▄▄▄▄▄▄▄───▄─
▀▀▄▄█████████▄▄▀▀
───██─▀███▀─██───
──▄▀████▀████▀▄──
▀█───██▀█▀██───█▀
░A N N I H I L A T I O N░
██████████████████'"

echo westwood > /proc/sys/net/ipv4/tcp_congestion_control

echo "2560,5120,11520,25600,35840,38400" > /sys/module/lowmemorykiller/parameters/minfree

for queue in /sys/block/mmcblk*/queue; do
  echo "deadline" > "$queue/scheduler"
  echo "0" > "$queue/add_random"
  echo "0" > "$queue/iostats"
  echo "128" > "$queue/read_ahead_kb"
  echo "64" > "$queue/nr_requests"
done

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Performing FSTrim and cleaning caches...

─▄───▄▄▄▄▄▄▄───▄─
▀▀▄▄█████████▄▄▀▀
───██─▀███▀─██───
──▄▀████▀████▀▄──
▀█───██▀█▀██───█▀
░A N N I H I L A T I O N░
██████████████████'"

fstrim -v /system
fstrim -v /vendor
fstrim -v /data
fstrim -v /cache
fstrim -v /system
fstrim -v /vendor
fstrim -v /metadata
fstrim -v /odm
fstrim -v /system_ext
fstrim -v  /product
fstrim -v /data
fstrim -v /cache

echo "3" > /proc/sys/vm/drop_caches

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Improving FPS, RAM Management and Entropy...
─▄───▄▄▄▄▄▄▄───▄─
▀▀▄▄█████████▄▄▀▀
───██─▀███▀─██───
──▄▀████▀████▀▄──
▀█───██▀█▀██───█▀
░A N N I H I L A T I O N░
██████████████████'"

setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'Removing Unnecessary Shit...
░░░░░░█░░░░░░░░▄▀▀░▐░░░
░░░░▄▀░░░░░░░░▐░▄▄▀░░░░
░░▄▀░░░▐░░░░░█▄▀░▐░░░░░
░░█░░░▐░░░░░░░░▄░█░░░░░
░░░█▄░░▀▄░░░░▄▀▐░█░░░░░
░░░█▐▀▀▀░▀▀▀▀░░▐░█░░░░░
░░▐█▐▄░░▀░░░░░░▐░█▄▄░░░
░░░▀▀▄░░░░░░░░▄▐▄▄▄▀░░░
░░░░░░░░░░░░░░░░░░░░░░░
'"

echo "UnityMain, libunity.so" > /proc/sys/kernel/sched_lib_name
echo "255" > /proc/sys/kernel/sched_lib_mask_force

cmd package bg-dexopt-job

su -lp 2000 -c "cmd notification post -S bigtext -t 'Annihilation Tweaks v3' 'Tag' 'All Tweaks have been Implemented into the Device and are Successfully Running. Do Join @R6gayming and give us feedbacks for more better Tweaks and Modules. #JaiShreeRam🇮🇳.
─────█─▄▀█──█▀▄─█─────
────▐▌──────────▐▌────
────█▌▀▄──▄▄──▄▀▐█────
───▐██──▀▀──▀▀──██▌───
──▄████▄──▐▌──▄████▄──
░░░A N N I H I L A T I O N░░░
██████████████████████'"

}

run > /dev/null 2>&1

